global.prefa = ['','!','.',',','🐤','🗿']
global.owner = ['6288708844767']
global.gambar = "https://files.catbox.moe/5gp130.jpg"
// GANTI NO OWNER DENGAN NOMOR MU LALU RUNN SEPERTI BIASA !!!